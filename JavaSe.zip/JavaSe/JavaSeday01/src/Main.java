import java.beans.PersistenceDelegate;

public class Main {
    public static void main(String[] args) {
        Person p1=new Person();
        p1.name="小明";
        p1.age=24;
        p1.gender="男";

        Person p2=new Person();
        p2.name="小红";
        System.out.println(p1.name+"和"+p2.name);
        Person p3=new Person();
        System.out.println(p3.name);
        System.out.println(p1);

        p1.eat();
        int result=p1.sum(1,2);
        System.out.println(result);
        p1.test(10);




        int a=10;int b=20;
        p1.swap(a,b);
        //System.out.println("a等于"+a+" b等于"+b);

        p1.modify(p1);
        System.out.println(p1.name);

        p2.setAge(18);
        p2.setGender("女");
        System.out.println(p2.getName()+p2.getAge()+p2.getGender());

        double result2=p1.sum(1.5,1.5);
        System.out.println(result2);

        int result3=p1.sum(1,2,3);
        System.out.println(result3);

        p1.say();

       int result4= p1.digui(100);
        System.out.println(result4);
    }
}
