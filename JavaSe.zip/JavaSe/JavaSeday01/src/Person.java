public class Person {
    String name;
    int age;
     String gender;
    public void eat(){
        System.out.println(name+"在吃饭");
    }

    public int sum(int a,int b){
        int c=a+b;
        return c;
    }
    public double sum(double a,double b){
        double c=a+b;
        return c;
    }
    public int sum(int a,int b,int c){
        return a+b+c;
    }

    public void test(int a){
        if(a==10){
            return;
        }
        System.out.println("hello world");
    }
    public void swap(int a,int b){
        int tmp=a;
        a=b;
        b=tmp;
        System.out.println("a等于"+a+" b等于"+b);
    }

    public void modify(Person p){
        p.name="新小明";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    public void say(){
        String language=Japanese();
        System.out.println(name+"说"+language);
    }
    public String Japanese(){
        return "日语";
    }

    public int digui(int n){
        if(n==0) return 0;
        return digui(n-1)+n;
    }
}
